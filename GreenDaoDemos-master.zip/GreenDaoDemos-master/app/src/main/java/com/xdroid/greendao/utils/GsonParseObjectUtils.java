package com.xdroid.greendao.utils;

import com.google.gson.Gson;

import java.lang.reflect.Type;

/**
 * Created by developer on 2018/1/29.
 */

public class GsonParseObjectUtils {

    /**
     * 返回 null为解析失败
     * @param json  json字符串
     * @param type  转化为javaBean
     * @param <T>   转化为定义的type类型
     * @return
     */
    public static <T> T jsonToObject(String json, Class<T> type) {
        Gson gson = new Gson();
        try {
            return gson.fromJson(json, type);
        } catch (Exception e) {
            return null;
        }
    }

    public static <T> T jsonToObject(String json, Type type) {
        Gson gson = new Gson();
        try {
            return gson.fromJson(json, type);
        } catch (Exception e) {
            return null;
        }
    }
}
