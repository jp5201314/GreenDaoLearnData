package com.xdroid.greendao.bean;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.annotation.ToMany;

import java.util.List;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.DaoException;
import com.xdroid.greendao.dao.DaoSession;
import com.xdroid.greendao.dao.OptionPanelBeanDao;
import com.xdroid.greendao.dao.SubGameBeanDao;

/**
 * Created by Administrator on 2018/7/9.
 */

@Entity
public  class SubGameBean {
    private String example;
    private String howToPaly;
    private String tip;
    @Id
    private String subGameId;
    private String subGameName;
    @Property(nameInDb = "subId")
    private String subId;
    @ToMany(referencedJoinProperty = "playMethodId")
    private List<OptionPanelBean> optionPanel;
    /** Used to resolve relations */
    @Generated(hash = 2040040024)
    private transient DaoSession daoSession;
    /** Used for active entity operations. */
    @Generated(hash = 2139962639)
    private transient SubGameBeanDao myDao;
    @Generated(hash = 1575658808)
    public SubGameBean(String example, String howToPaly, String tip,
            String subGameId, String subGameName, String subId) {
        this.example = example;
        this.howToPaly = howToPaly;
        this.tip = tip;
        this.subGameId = subGameId;
        this.subGameName = subGameName;
        this.subId = subId;
    }
    @Generated(hash = 1769079530)
    public SubGameBean() {
    }
    public String getExample() {
        return this.example;
    }
    public void setExample(String example) {
        this.example = example;
    }
    public String getHowToPaly() {
        return this.howToPaly;
    }
    public void setHowToPaly(String howToPaly) {
        this.howToPaly = howToPaly;
    }
    public String getTip() {
        return this.tip;
    }
    public void setTip(String tip) {
        this.tip = tip;
    }
    public String getSubGameId() {
        return this.subGameId;
    }
    public void setSubGameId(String subGameId) {
        this.subGameId = subGameId;
    }
    public String getSubGameName() {
        return this.subGameName;
    }
    public void setSubGameName(String subGameName) {
        this.subGameName = subGameName;
    }
    public String getSubId() {
        return this.subId;
    }
    public void setSubId(String subId) {
        this.subId = subId;
    }
    /**
     * To-many relationship, resolved on first access (and after reset).
     * Changes to to-many relations are not persisted, make changes to the target entity.
     */
    @Generated(hash = 1102341183)
    public List<OptionPanelBean> getOptionPanel() {
        if (optionPanel == null) {
            final DaoSession daoSession = this.daoSession;
            if (daoSession == null) {
                throw new DaoException("Entity is detached from DAO context");
            }
            OptionPanelBeanDao targetDao = daoSession.getOptionPanelBeanDao();
            List<OptionPanelBean> optionPanelNew = targetDao
                    ._querySubGameBean_OptionPanel(subGameId);
            synchronized (this) {
                if (optionPanel == null) {
                    optionPanel = optionPanelNew;
                }
            }
        }
        return optionPanel;
    }
    /** Resets a to-many relationship, making the next get call to query for a fresh result. */
    @Generated(hash = 730426259)
    public synchronized void resetOptionPanel() {
        optionPanel = null;
    }
    /**
     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#delete(Object)}.
     * Entity must attached to an entity context.
     */
    @Generated(hash = 128553479)
    public void delete() {
        if (myDao == null) {
            throw new DaoException("Entity is detached from DAO context");
        }
        myDao.delete(this);
    }
    /**
     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#refresh(Object)}.
     * Entity must attached to an entity context.
     */
    @Generated(hash = 1942392019)
    public void refresh() {
        if (myDao == null) {
            throw new DaoException("Entity is detached from DAO context");
        }
        myDao.refresh(this);
    }
    /**
     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#update(Object)}.
     * Entity must attached to an entity context.
     */
    @Generated(hash = 713229351)
    public void update() {
        if (myDao == null) {
            throw new DaoException("Entity is detached from DAO context");
        }
        myDao.update(this);
    }
    /** called by internal mechanisms, do not call yourself. */
    @Generated(hash = 1577061483)
    public void __setDaoSession(DaoSession daoSession) {
        this.daoSession = daoSession;
        myDao = daoSession != null ? daoSession.getSubGameBeanDao() : null;
    }

    @Override
    public String toString() {
        return "SubGameBean{" +
                "example='" + example + '\'' +
                ", howToPaly='" + howToPaly + '\'' +
                ", tip='" + tip + '\'' +
                ", subGameId='" + subGameId + '\'' +
                ", subGameName='" + subGameName + '\'' +
                ", subId='" + subId + '\'' +
                '}';
    }
}
