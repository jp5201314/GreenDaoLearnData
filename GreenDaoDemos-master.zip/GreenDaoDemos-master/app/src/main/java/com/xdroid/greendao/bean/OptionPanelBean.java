package com.xdroid.greendao.bean;

import com.xdroid.greendao.utils.StringConverter;

import org.greenrobot.greendao.annotation.Convert;
import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;

import java.util.List;
import org.greenrobot.greendao.annotation.Generated;

/**
 * Created by Administrator on 2018/7/9.
 */


@Entity
public  class OptionPanelBean {
    /**
     * charList : ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49"]
     * display : 1
     * leftText : 特码
     */
    @Id
    private Long id;
    private String display;
    private String leftText;
    @Convert(columnType = String.class, converter = StringConverter.class)
    private List<String> charList;
    @Property(nameInDb = "playMethodId")
    private String playMethodId;
    @Generated(hash = 2062118628)
    public OptionPanelBean(Long id, String display, String leftText, List<String> charList, String playMethodId) {
        this.id = id;
        this.display = display;
        this.leftText = leftText;
        this.charList = charList;
        this.playMethodId = playMethodId;
    }
    @Generated(hash = 641655128)
    public OptionPanelBean() {
    }
    public Long getId() {
        return this.id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getDisplay() {
        return this.display;
    }
    public void setDisplay(String display) {
        this.display = display;
    }
    public String getLeftText() {
        return this.leftText;
    }
    public void setLeftText(String leftText) {
        this.leftText = leftText;
    }
    public List<String> getCharList() {
        return this.charList;
    }
    public void setCharList(List<String> charList) {
        this.charList = charList;
    }
    public String getPlayMethodId() {
        return this.playMethodId;
    }
    public void setPlayMethodId(String playMethodId) {
        this.playMethodId = playMethodId;
    }

    @Override
    public String toString() {
        return "OptionPanelBean{" +
                "id=" + id +
                ", display='" + display + '\'' +
                ", leftText='" + leftText + '\'' +
                ", charList=" + charList +
                ", playMethodId='" + playMethodId + '\'' +
                '}';
    }
}
