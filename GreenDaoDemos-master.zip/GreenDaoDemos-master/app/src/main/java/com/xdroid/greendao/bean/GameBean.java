package com.xdroid.greendao.bean;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.ToMany;

import java.util.List;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.DaoException;
import com.xdroid.greendao.dao.DaoSession;
import com.xdroid.greendao.dao.SubGameBeanDao;
import com.xdroid.greendao.dao.GameBeanDao;

/**
 * Created by Administrator on 2018/7/9.
 */
@Entity
public class GameBean {

    private String gameName;
    @Id
    private String gameNameId;
    @ToMany(referencedJoinProperty = "subId")
    private List<SubGameBean> subGame;
    /** Used to resolve relations */
    @Generated(hash = 2040040024)
    private transient DaoSession daoSession;
    /** Used for active entity operations. */
    @Generated(hash = 1899358033)
    private transient GameBeanDao myDao;
    @Generated(hash = 391313362)
    public GameBean(String gameName, String gameNameId) {
        this.gameName = gameName;
        this.gameNameId = gameNameId;
    }
    @Generated(hash = 1942203655)
    public GameBean() {
    }
    public String getGameName() {
        return this.gameName;
    }
    public void setGameName(String gameName) {
        this.gameName = gameName;
    }
    public String getGameNameId() {
        return this.gameNameId;
    }
    public void setGameNameId(String gameNameId) {
        this.gameNameId = gameNameId;
    }
    /**
     * To-many relationship, resolved on first access (and after reset).
     * Changes to to-many relations are not persisted, make changes to the target entity.
     */
    @Generated(hash = 437524646)
    public List<SubGameBean> getSubGame() {
        if (subGame == null) {
            final DaoSession daoSession = this.daoSession;
            if (daoSession == null) {
                throw new DaoException("Entity is detached from DAO context");
            }
            SubGameBeanDao targetDao = daoSession.getSubGameBeanDao();
            List<SubGameBean> subGameNew = targetDao
                    ._queryGameBean_SubGame(gameNameId);
            synchronized (this) {
                if (subGame == null) {
                    subGame = subGameNew;
                }
            }
        }
        return subGame;
    }
    /** Resets a to-many relationship, making the next get call to query for a fresh result. */
    @Generated(hash = 551408038)
    public synchronized void resetSubGame() {
        subGame = null;
    }
    /**
     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#delete(Object)}.
     * Entity must attached to an entity context.
     */
    @Generated(hash = 128553479)
    public void delete() {
        if (myDao == null) {
            throw new DaoException("Entity is detached from DAO context");
        }
        myDao.delete(this);
    }
    /**
     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#refresh(Object)}.
     * Entity must attached to an entity context.
     */
    @Generated(hash = 1942392019)
    public void refresh() {
        if (myDao == null) {
            throw new DaoException("Entity is detached from DAO context");
        }
        myDao.refresh(this);
    }
    /**
     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#update(Object)}.
     * Entity must attached to an entity context.
     */
    @Generated(hash = 713229351)
    public void update() {
        if (myDao == null) {
            throw new DaoException("Entity is detached from DAO context");
        }
        myDao.update(this);
    }
    /** called by internal mechanisms, do not call yourself. */
    @Generated(hash = 724433682)
    public void __setDaoSession(DaoSession daoSession) {
        this.daoSession = daoSession;
        myDao = daoSession != null ? daoSession.getGameBeanDao() : null;
    }

    @Override
    public String toString() {
        return "GameBean{" +
                "gameName='" + gameName + '\'' +
                ", gameNameId='" + gameNameId + '\'' +
                '}';
    }
}
