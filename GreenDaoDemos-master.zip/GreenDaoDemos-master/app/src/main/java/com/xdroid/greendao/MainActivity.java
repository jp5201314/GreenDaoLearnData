package com.xdroid.greendao;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import com.xdroid.greendao.bean.GameBean;
import com.xdroid.greendao.bean.OptionPanelBean;
import com.xdroid.greendao.bean.SubGameBean;
import com.xdroid.greendao.bean.User;
import com.xdroid.greendao.dao.DBController;
import com.xdroid.greendao.dao.DaoMaster;
import com.xdroid.greendao.dao.DaoSession;
import com.xdroid.greendao.dao.GameBeanDao;
import com.xdroid.greendao.dao.InfoBeanDao;
import com.xdroid.greendao.dao.OptionPanelBeanDao;
import com.xdroid.greendao.dao.OrderDao;
import com.xdroid.greendao.dao.SubGameBeanDao;
import com.xdroid.greendao.dao.UserDao;
import com.xdroid.greendao.utils.DBUtils;
import com.xdroid.greendao.utils.GsonParseObjectUtils;
import com.xdroid.greendao.utils.TransferJsonFileToStringUtils;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;

public class MainActivity extends Activity {

    private DaoMaster daoMaster;
    private DaoSession localDaoSession;
    private DaoSession userDaoSession;
    private OrderDao orderDao;
    private UserDao userDao;
    private GameBean gameBean;
    private InfoBeanDao infoBeanDao;
    private GameBeanDao gameBeanDao;
    private SubGameBeanDao subGameBeanDao;
    private OptionPanelBeanDao optionPanelBeanDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Type type = new TypeToken<GameBean>() {
        }.getType();
        gameBean = GsonParseObjectUtils.jsonToObject(TransferJsonFileToStringUtils.getJson(this, "xglhc.json"), type);
        Log.d("TAG",gameBean.toString());


    }

    public void createDatabase(View view) {
        /*DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(this, "user.db");
        daoMaster = new DaoMaster(helper.getWritableDb());
        daoSession = daoMaster.newSession();
        orderDao = daoSession.getOrderDao();
        userDao = daoSession.getUserDao();
        infoBeanDao = daoSession.getInfoBeanDao();
        gameBeanDao = daoSession.getGameBeanDao();
        subGameBeanDao = daoSession.getSubGameBeanDao();
        optionPanelBeanDao = daoSession.getOptionPanelBeanDao();*/
        localDaoSession = DBController.getDaoSession();
        userDao = localDaoSession.getUserDao();
        copyRawDB();

    }
    private void copyRawDB()
    {
        try
        {
            // 拷贝res/raw/xxxxdb.zip 到
            // /data/data/com.xinhang.mobileclient/databases/ 目录下面
            boolean isSuccess = DBUtils.copyRawDBToApkDb(MainActivity.this,R.raw.user , DBUtils.APK_DB_PATH, DBUtils.ECMC_DB_NAME, false);
            Toast.makeText(this,String.valueOf(isSuccess),Toast.LENGTH_SHORT).show();
            userDaoSession = DBController.getDaoSession(DBController.DATABASE_SCHOOL_NAME);
            gameBeanDao = userDaoSession.getGameBeanDao();
            subGameBeanDao = userDaoSession.getSubGameBeanDao();
            optionPanelBeanDao = userDaoSession.getOptionPanelBeanDao();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
    public void insert(View view) {
        User user = new User("1","蒋平");
        userDao.insert(user);

/*        long num = gameBeanDao.insertOrReplace(gameBean);
        long subName = 0;
        long optionPanel = 0;
        for (SubGameBean subGameBean : gameBean.getSubGame()) {
                 subName = subGameBeanDao.insertOrReplace(subGameBean);
            for (OptionPanelBean optionPanelBean : subGameBean.getOptionPanel()) {
                 optionPanel = optionPanelBeanDao.insertOrReplace(optionPanelBean);
            }
        }

        if (num!=0&&subName!=0&&optionPanel!=0){
            Toast.makeText(this,"插入成功",Toast.LENGTH_SHORT).show();
        }*/

      /*  User user = new User("1","蒋平");
        Order order1 = new Order("1","语文","1");
        Order order2 = new Order("2","数学","1");
        Order order3 = new Order("3","英语","1");
        InfoBean infoBean1 = new InfoBean("语法","1");
        InfoBean infoBean2 = new InfoBean("拼音","1");
        InfoBean infoBean3 = new InfoBean("算数","2");
        InfoBean infoBean4 = new InfoBean("选择","2");
        InfoBean infoBean5 = new InfoBean("单词","3");
        InfoBean infoBean6 = new InfoBean("作文","3");
        infoBeanDao.insertInTx(infoBean1,infoBean2,infoBean3,infoBean4,infoBean5,infoBean6);
        orderDao.insertInTx(order1,order2,order3);
        userDao.insertInTx(user);*/
     /* SubGameBean subGameBean = new SubGameBean("五星",1L);
      PlayMethodBean playMethodBean = new PlayMethodBean("dsa","dsa","tip","直选复式",0L,1L);
      OptionPanelBean optionPanelBean1 = new OptionPanelBean(0L,"1","万",0L);
      OptionPanelBean optionPanelBean2 = new OptionPanelBean(1L,"1","千",0L);
      OptionPanelBean optionPanelBean3 = new OptionPanelBean(2L,"1","百",0L);
      OptionPanelBean optionPanelBean4 = new OptionPanelBean(3L,"1","十",0L);
      OptionPanelBean optionPanelBean5 = new OptionPanelBean(4L,"1","个",0L);
        CharBean  charBea1= new CharBean("0",0L);
        CharBean  charBean2 = new CharBean("1",0L);
        CharBean  charBean3 = new CharBean("0",1L);
        CharBean  charBean4 = new CharBean("1",1L);
        CharBean  charBean5 = new CharBean("0",2L);
        CharBean  charBean6 = new CharBean("1",2L);
        CharBean  charBean7= new CharBean("0",3L);
        CharBean  charBean8 = new CharBean("1",3L);
        CharBean  charBean9 = new CharBean("0",4L);
        CharBean  charBean10 = new CharBean("1",4L);
       subGameBeanDao.insert(subGameBean);
       playMethodBeanDao.insert(playMethodBean);
       optionPanelBeanDao.insertInTx(optionPanelBean1,optionPanelBean2,optionPanelBean3,optionPanelBean4,optionPanelBean5);
        charBeanDao.insertInTx(charBea1,charBean2,charBean3,charBean4,charBean5,charBean6,charBean7,charBean8,charBean9,charBean10);*/
    }

    public void query(View view) {

    }

    public void queryAllOrders(View view) {
    /*    List<User> list = userDao.queryBuilder().list();
        for (User user : list) {
            List<Order> orderList = user.getOrders();
            for (Order order : orderList) {
                List<InfoBean> infoBeans = order.getInfoBeans();
                for (InfoBean infoBean : infoBeans) {
                    Log.d("TAG",user.getName()+":"+order.getOrderName()+":"+infoBean.getInfoName());
                }
            }
        }*/
        List<GameBean> gameBeans = gameBeanDao.queryBuilder().list();
        for (GameBean bean : gameBeans) {
            List<SubGameBean> subGameBeans = bean.getSubGame();
            for (SubGameBean subGameBean : subGameBeans) {
                List<OptionPanelBean> optionPanelBeans = subGameBean.getOptionPanel();
                for (OptionPanelBean optionPanelBean : optionPanelBeans) {
                    Log.d("TAG",bean.toString()+"\n"+subGameBean.toString()+"\n"+optionPanelBean.toString());
                }
            }
        }
    }
}
