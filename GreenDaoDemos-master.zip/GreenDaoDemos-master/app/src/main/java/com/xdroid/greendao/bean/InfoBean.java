package com.xdroid.greendao.bean;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.annotation.Generated;

/**
 * Created by Administrator on 2018/7/9.
 */
@Entity
public class InfoBean {
    @Id(autoincrement = true)
    private Long id;

    @Property(nameInDb = "infoName")
    private String infoName;

    @Property(nameInDb = "infoId")
    private String infoId;

    @Generated(hash = 1251328356)
    public InfoBean(Long id, String infoName, String infoId) {
        this.id = id;
        this.infoName = infoName;
        this.infoId = infoId;
    }

    public InfoBean(String infoName, String infoId) {
        this.infoName = infoName;
        this.infoId = infoId;
    }

    @Generated(hash = 134777477)
    public InfoBean() {
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getInfoName() {
        return this.infoName;
    }

    public void setInfoName(String infoName) {
        this.infoName = infoName;
    }

    public String getInfoId() {
        return this.infoId;
    }

    public void setInfoId(String infoId) {
        this.infoId = infoId;
    }


}
